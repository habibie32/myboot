https://eveltc.xyz/?ref=12291
https://evedoge.xyz/?ref=11596
https://evexrp.xyz/?ref=18594
https://evetrx.xyz/?ref=10905