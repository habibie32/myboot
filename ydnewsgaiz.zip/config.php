<?php

// config
$config = [
    "imei" => [
    
"114467357837496",

],
    "sign" => [
    
"b8f880af4d31d8c6c7b05c4ed43f36fb1168a2ff",

],
   "token" => [
   
"a27b866aaa75204d07a6c877d5aebcaf",

],
    "uuid" => [
    
"60d701a1-dc64-4d64-b9ea-ca77fbcf119b",

],
 ];





?>
