<?php
$android_id = "7b45078b5ee13af9";
$deviceCode = "354554070160625";
$device_ip  = "182.0.165.177";
$token = "f05bggvIRMnRYNQiZCUPZQCP4SQa2KMjrPq9nqI_3GlPSg2RuZ5mkpa1GYgla_99g0TmV3_untGT-dw";
$tk = "ACCgUmbG3b9N8LW809_8bZeYt726gnBuyc5xdHRodw";
$uuid = "022e9db7eb1241678736b1d282371540";
$userid = "7042082";
$sign = "49a11733afb24feec79ef2a037092ad3";

####################################################
#|note:
#| *untuk aktifitas nuyul multi akun
#|  gunakan andoid_id yang berbeda setiap akun
#|  gunakan devicecode (imei) yang berbeda setiap akun
#|  gunakan device_ip yang berbeda setiap akun
#| *untuk settingan lainya wajib sama 
#|  dengan data dari packet capture
#|
####################################################
#| cara mengaktifkan multi akun
#| duplikat data di atas dari anroid_id => sign
#| buat file baru dengan nama bebas terserah kamu
#| aktifkan skrip di bawah dngn menghapus tanda pagar
#| jika skrip di aktifkan maka hapus data di atas 
#|#####################################################
#| hapus pagar di bawah untuk mengaktifkan skrip

# include(readline("masukan config: "));
