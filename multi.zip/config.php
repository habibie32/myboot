<?php

$id_akun=[
38148, //id akun satu
38150, //id akun dua
29772,
30137,
29783,
30869,
30871,
30874,
30876,
30878,
30884,
37524,
37541,
38154,
38153,
];
$email_login=[
"andisianturie@gmail.com", //email akun satu
"wallercarolina550@gmail.com", //email akun dua
"gaizmania25@gmail.com",
"almerbarokah@gmail.com",
"jimmybozka@gmail.com",
"ahmedhabibie@gmail.com",
"analontong45@gmail.com",
"solehimoets@gmail.com",
"imotkuceng@gmail.com",
"vitamania93@gmail.com",
"arthurgantenge@gmail.com",
"legendzanis@gmail.com",
"valheinfast@gmail.com",
"edwardweaver212@gmail.com",
"laurawilson739@gmail.com",


];
