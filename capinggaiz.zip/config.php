<?php
$config = [
"u=62726084;n=ffffffffbae251ec3c9e5afe374a3ead",


];