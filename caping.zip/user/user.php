<?php
$stat_sseth=true;
$msgsseth= "[---] enjoy your life";
$stat_cp = true;
$msgcp = "[--] enjoy your life";
$figlet= $ijo."
───────────────────────────────────────────
── ▄▀ ▄▀▄ █▀▄ ▀ █▄─█ ▄▀▀ ".$kuning." [`  ||    _    _.       
── █─ █▀█ █─█ █ █─▀█ █─▀▌".$kuning." | L||| \/(/_|`_\|".$ijo."
── ─▀ ▀─▀ █▀─ ▀ ▀──▀ ▀▀▀───────────────────".$t.
  $putih."creator:".$ijo." adidoank   ".$putih."[--]  ide  :".$ijo." sungging  ".$t.
  $putih."chanel :".$ijo." adi bordir ".$putih."[--] chanel:".$ijo." sungging  ".$t.
  $putih."invite :".$ijo." ipzme2     ".$putih."[--] invite:".$ijo."  otr3o8   ".$t;
