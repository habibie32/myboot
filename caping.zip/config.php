<?php
$config = [
"u=62704506;n=ffffffffcecf941affffffffda80ec28",


];